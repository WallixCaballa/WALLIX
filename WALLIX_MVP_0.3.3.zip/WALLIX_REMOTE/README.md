# WALLIX 0.3.1 — Remote Catalog

WALLIX now supports a remote JSON catalog with a safe local fallback.

## How it works
1. The app starts from the bundled `assets/catalog.json`.
2. It tries to download the remote catalog from `REMOTE_CATALOG_URL`.
3. If the remote catalog is reachable and valid, it replaces the local catalog.
4. If it fails, the app continues using the local demo catalogue.

## Important: one hosting step remains
The app is configured to use the WALLIX GitHub Pages catalog at `https://wallixcaballa.github.io/wallix-catalog/catalog.json`.

Recommended simple setup:
- Create a public GitHub repository called `wallix-catalog`.
- Enable GitHub Pages for the repository.
- Upload `catalog/catalog.json` (or put it at the site root).
- The remote catalog is already configured in `MainActivity.kt`.

For real wallpapers, set each `imageUrl` in `catalog.json` to a public HTTPS image URL. The app can then load those images remotely while retaining the local fallback.

## Current demo state
The 12 demo wallpapers remain in the APK. The remote catalog currently mirrors them, so we can test the catalogue architecture before replacing the images.
