package com.wallix.app

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.LaunchedEffect
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val WallixBlue = Color(0xFF00A5FF)
private val WallixBlack = Color(0xFF050607)
private val WallixCard = Color(0xFF111416)

private data class Wallpaper(
    val id: Int,
    val title: String,
    val category: String,
    val resourceName: String,
    val imageUrl: String? = null
)

private const val REMOTE_CATALOG_URL = "https://wallixcaballa.github.io/wallix-catalog/catalog.json"

private val fallbackWallpapers = listOf(
    Wallpaper(1, "Universos infinitos", "Espacio", "wallpaper_universos"),
    Wallpaper(2, "Dragón ancestral", "Fantasía", "wallpaper_dragon"),
    Wallpaper(3, "Blue Flow", "AMOLED", "wallpaper_blueflow"),
    Wallpaper(4, "Alpine Lake", "Naturaleza", "wallpaper_alpinelake"),
    Wallpaper(5, "Night Drive", "Motor", "wallpaper_nightdrive"),
    Wallpaper(6, "Neon City", "Tecnología", "wallpaper_neoncity"),
    Wallpaper(7, "Wild Soul", "Animales", "wallpaper_wildsoul"),
    Wallpaper(8, "Silent Forms", "Minimalista", "wallpaper_silentforms"),
    Wallpaper(9, "Moon Peak", "Naturaleza", "wallpaper_moonpeak"),
    Wallpaper(10, "Red Horizon", "Espacio", "wallpaper_redhorizon"),
    Wallpaper(11, "Rain Leaf", "Naturaleza", "wallpaper_rainleaf"),
    Wallpaper(12, "Hidden Falls", "Naturaleza", "wallpaper_hiddenfalls")
)

private val categories = listOf("Espacio", "Fantasía", "AMOLED", "Naturaleza", "Motor", "Tecnología", "Animales", "Minimalista")

private fun parseCatalog(json: String): List<Wallpaper> {
    val array = JSONArray(json)
    return buildList {
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            add(
                Wallpaper(
                    id = o.getInt("id"),
                    title = o.getString("title"),
                    category = o.getString("category"),
                    resourceName = o.optString("resource", ""),
                    imageUrl = o.optString("imageUrl").takeIf { it.isNotBlank() }
                )
            )
        }
    }
}

private fun loadLocalCatalog(context: Context): List<Wallpaper> {
    return try {
        context.assets.open("catalog.json").bufferedReader().use { parseCatalog(it.readText()) }
            .ifEmpty { fallbackWallpapers }
    } catch (_: Exception) { fallbackWallpapers }
}

private fun loadRemoteCatalog(): List<Wallpaper>? {
    if (REMOTE_CATALOG_URL.contains("YOUR_GITHUB_USERNAME")) return null
    return try {
        val connection = (URL(REMOTE_CATALOG_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 7000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        connection.inputStream.bufferedReader().use { parseCatalog(it.readText()) }
            .takeIf { it.isNotEmpty() }
            .also { connection.disconnect() }
    } catch (_: Exception) { null }
}

private suspend fun loadCatalog(context: Context): Pair<List<Wallpaper>, Boolean> {
    val remote = loadRemoteCatalog()
    return if (remote != null) remote to true else loadLocalCatalog(context) to false
}

private fun resourceId(context: Context, wp: Wallpaper): Int =
    context.resources.getIdentifier(wp.resourceName, "drawable", context.packageName)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WallixApp(applicationContext) }
    }
}

@Composable
private fun WallixApp(context: Context) {
    var wallpapers by remember { mutableStateOf(loadLocalCatalog(context)) }
    var usingRemoteCatalog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val (catalog, remote) = loadCatalog(context)
        wallpapers = catalog
        usingRemoteCatalog = remote
    }
    val prefs = remember { context.getSharedPreferences("wallix", Context.MODE_PRIVATE) }
    var favorites by remember {
        mutableStateOf(prefs.getStringSet("favorites", emptySet())!!.mapNotNull { it.toIntOrNull() }.toSet())
    }
    fun toggleFavorite(id: Int) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putStringSet("favorites", favorites.map(Int::toString).toSet()).apply()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = WallixBlack,
            surface = WallixCard,
            primary = WallixBlue,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        val nav = rememberNavController()
        Scaffold(
            containerColor = WallixBlack,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0A0C0D)) {
                    NavItem(nav, "home", "Inicio", Icons.Default.Home)
                    NavItem(nav, "categories", "Categorías", Icons.Default.GridView)
                    NavItem(nav, "favorites", "Favoritos", Icons.Default.Favorite)
                    NavItem(nav, "settings", "Ajustes", Icons.Default.Settings)
                }
            }
        ) { padding ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") { HomeScreen(nav, wallpapers, favorites, ::toggleFavorite) }
                composable("categories") { CategoriesScreen(nav) }
                composable("favorites") { FavoritesScreen(nav, wallpapers, favorites, ::toggleFavorite) }
                composable("settings") { SettingsScreen(usingRemoteCatalog) }
                composable("search") { SearchScreen(nav, wallpapers, favorites, ::toggleFavorite) }
                composable("wallpaper/{id}") { entry ->
                    val id = entry.arguments?.getString("id")?.toIntOrNull() ?: 1
                    wallpapers.firstOrNull { it.id == id }?.let { wp ->
                        WallpaperScreen(context, wp, id in favorites, { toggleFavorite(id) }) { nav.popBackStack() }
                    }
                }
                composable("category/{name}") { entry ->
                    val name = entry.arguments?.getString("name").orEmpty()
                    CategoryScreen(name, nav, wallpapers, favorites, ::toggleFavorite)
                }
            }
        }
    }
}

@Composable
private fun NavItem(nav: NavHostController, route: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    NavigationBarItem(
        selected = current == route,
        onClick = { nav.navigate(route) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true } },
        icon = { Icon(icon, null) },
        label = { Text(label) },
        colors = NavigationBarItemDefaults.colors(selectedIconColor = WallixBlue, selectedTextColor = WallixBlue, indicatorColor = Color.Transparent)
    )
}

@Composable
private fun HomeScreen(nav: NavHostController, wallpapers: List<Wallpaper>, favorites: Set<Int>, onFavorite: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("WALLIX", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("Fondos que hacen diferente tu pantalla", color = Color.Gray)
            }
            IconButton(onClick = { nav.navigate("search") }) { Icon(Icons.Default.Search, "Buscar") }
        }
        Spacer(Modifier.height(18.dp))
        WallpaperCard(wallpapers[0], Modifier.fillMaxWidth().height(220.dp), favorites.contains(1), { onFavorite(1) }) { nav.navigate("wallpaper/${it.id}") }
        Spacer(Modifier.height(22.dp))
        SectionHeader("Categorías") { nav.navigate("categories") }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
            items(categories) { CategoryTile(it) { nav.navigate("category/$it") } }
        }
        Spacer(Modifier.height(22.dp))
        SectionHeader("Nuevos fondos") { nav.navigate("category/Nuevos") }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(310.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
            items(wallpapers.takeLast(4)) { wp ->
                WallpaperCard(wp, Modifier.fillMaxWidth().height(290.dp), favorites.contains(wp.id), { onFavorite(wp.id) }) { nav.navigate("wallpaper/${it.id}") }
            }
        }
    }
}

@Composable private fun SectionHeader(title: String, onMore: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text("Ver todas", color = WallixBlue, modifier = Modifier.clickable { onMore() })
    }
}

@Composable private fun CategoryTile(name: String, onClick: () -> Unit) {
    Box(Modifier.height(165.dp).clip(RoundedCornerShape(18.dp)).background(categoryColor(name)).clickable { onClick() }.padding(10.dp), contentAlignment = Alignment.BottomStart) {
        Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

private fun categoryColor(name: String) = when (name) {
    "Espacio" -> Color(0xFF5530A8); "Fantasía" -> Color(0xFF5B2C16); "AMOLED" -> Color(0xFF063A82); "Naturaleza" -> Color(0xFF126A61)
    "Motor" -> Color(0xFF6E1720); "Tecnología" -> Color(0xFF5C146B); "Animales" -> Color(0xFF805020); else -> Color(0xFF4A4A4A)
}

@Composable
private fun WallpaperImage(wp: Wallpaper, modifier: Modifier) {
    if (!wp.imageUrl.isNullOrBlank()) {
        coil3.compose.AsyncImage(
            model = wp.imageUrl,
            contentDescription = wp.title,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    } else {
        Image(
            painter = painterResource(resourceId(LocalContext.current, wp)),
            contentDescription = wp.title,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun WallpaperCard(wp: Wallpaper, modifier: Modifier, favorite: Boolean, onFavorite: () -> Unit, onClick: (Wallpaper) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).clickable { onClick(wp) }) {
        WallpaperImage(wp, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f)))
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) { Text(wp.title, fontWeight = FontWeight.Bold); Text(wp.category, color = Color.LightGray, fontSize = 12.sp) }
        IconButton(Modifier.align(Alignment.TopEnd), onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) WallixBlue else Color.White) }
    }
}

@Composable private fun CategoriesScreen(nav: NavHostController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Categorías", fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(categories) { CategoryTile(it) { nav.navigate("category/$it") } } }
    }
}

@Composable private fun CategoryScreen(name: String, nav: NavHostController, wallpapers: List<Wallpaper>, favorites: Set<Int>, onFavorite: (Int) -> Unit) {
    val list = if (name == "Nuevos") wallpapers.takeLast(4) else wallpapers.filter { it.category == name }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text(name, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { wp -> WallpaperCard(wp, Modifier.height(320.dp), favorites.contains(wp.id), { onFavorite(wp.id) }) { nav.navigate("wallpaper/${it.id}") } }
        }
    }
}

@Composable private fun FavoritesScreen(nav: NavHostController, wallpapers: List<Wallpaper>, favorites: Set<Int>, onFavorite: (Int) -> Unit) {
    val list = wallpapers.filter { it.id in favorites }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Favoritos", fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("Tus fondos guardados", color = Color.Gray); Spacer(Modifier.height(16.dp))
        if (list.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Todavía no tienes favoritos", color = Color.Gray) }
        else LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { wp -> WallpaperCard(wp, Modifier.height(320.dp), true, { onFavorite(wp.id) }) { nav.navigate("wallpaper/${it.id}") } } }
    }
}

@Composable private fun SearchScreen(nav: NavHostController, wallpapers: List<Wallpaper>, favorites: Set<Int>, onFavorite: (Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = wallpapers.filter { it.title.contains(query, true) || it.category.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; OutlinedTextField(query, { query = it }, Modifier.weight(1f), placeholder = { Text("Buscar fondos") }, singleLine = true) }
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(results) { wp -> WallpaperCard(wp, Modifier.height(320.dp), favorites.contains(wp.id), { onFavorite(wp.id) }) { nav.navigate("wallpaper/${it.id}") } } }
    }
}

@Composable private fun WallpaperScreen(context: Context, wp: Wallpaper, favorite: Boolean, onFavorite: () -> Unit, onBack: () -> Unit) {
    var showApply by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        WallpaperImage(wp, Modifier.fillMaxSize())
        IconButton(Modifier.align(Alignment.TopStart).padding(8.dp), onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
        Row(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ActionButton(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", onFavorite)
            ActionButton(Icons.Default.Download, "Descargar") { saveToGallery(context, wp) }
            ActionButton(Icons.Default.Wallpaper, "Aplicar") { showApply = true }
        }
    }
    if (showApply) ApplyDialog(context, wp) { showApply = false }
}

@Composable private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { FilledIconButton(onClick = onClick, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = .72f))) { Icon(icon, null) }; Text(text, fontSize = 12.sp, color = Color.White) }
}

@Composable private fun ApplyDialog(context: Context, wp: Wallpaper, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aplicar fondo de pantalla") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ApplyOption("Pantalla de inicio") { applyWallpaper(context, wp, WallpaperManager.FLAG_SYSTEM); onDismiss() }
                ApplyOption("Pantalla de bloqueo") { applyWallpaper(context, wp, WallpaperManager.FLAG_LOCK); onDismiss() }
                ApplyOption("Ambas pantallas") { applyWallpaper(context, wp, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK); onDismiss() }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = WallixCard
    )
}

@Composable private fun ApplyOption(title: String, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() }, color = Color(0xFF1B1F21), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Wallpaper, null, tint = WallixBlue); Spacer(Modifier.width(12.dp)); Text(title) }
    }
}

private fun openWallpaperStream(context: Context, wp: Wallpaper): java.io.InputStream {
    return if (!wp.imageUrl.isNullOrBlank()) {
        URL(wp.imageUrl).openStream()
    } else {
        context.resources.openRawResource(resourceId(context, wp))
    }
}

private fun applyWallpaper(context: Context, wp: Wallpaper, flags: Int) {
    try {
        val manager = WallpaperManager.getInstance(context)
        openWallpaperStream(context, wp).use { input -> manager.setStream(input, null, true, flags) }
        Toast.makeText(context, "Fondo aplicado", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) { Toast.makeText(context, "No se pudo aplicar el fondo", Toast.LENGTH_SHORT).show() }
}

private fun saveToGallery(context: Context, wp: Wallpaper) {
    try {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "WALLIX_${wp.id}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WALLIX")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException()
        resolver.openOutputStream(uri).use { out -> openWallpaperStream(context, wp).use { input -> input.copyTo(out!!) } }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0); resolver.update(uri, values, null, null) }
        Toast.makeText(context, "Guardado en Galería / WALLIX", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) { Toast.makeText(context, "No se pudo guardar el fondo", Toast.LENGTH_SHORT).show() }
}

@Composable private fun SettingsScreen(usingRemoteCatalog: Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Ajustes", fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp))
        SettingRow(Icons.Default.DarkMode, "Modo oscuro", "Activado", true)
        SettingRow(Icons.Default.Folder, "Guardar en", "Galería del dispositivo")
        SettingRow(Icons.Default.Delete, "Borrar caché", "Próximamente")
        SettingRow(Icons.Default.Cloud, "Catálogo", if (usingRemoteCatalog) "Conectado" else "Modo local")
        SettingRow(Icons.Default.Info, "Acerca de WALLIX", "v0.3.1")
    }
}

@Composable private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String, toggle: Boolean = false) {
    Surface(color = WallixCard, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = WallixBlue); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(value, color = Color.Gray, fontSize = 12.sp) }
            if (toggle) Switch(true, {}) else Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
        }
    }
}
