# Compilar WALLIX desde GitHub

Este proyecto incluye un workflow de GitHub Actions en `.github/workflows/build-apk.yml`.

Cada push a `main` o una ejecución manual compila el APK debug y lo publica como artifact llamado `WALLIX-debug-apk`.

No se necesita ordenador ni Android Studio para la compilación: GitHub Actions ejecuta Gradle en la nube.
