# WALLIX remote catalog

This folder is intended to be published as a static website (for example GitHub Pages).

`catalog.json` is the data source read by the app.

When replacing the demo wallpapers, set `imageUrl` to the public HTTPS URL of each final image. Keep IDs stable.
